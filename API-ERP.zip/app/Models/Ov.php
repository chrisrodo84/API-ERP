<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ov extends Model
{
    protected $table = 'ov';
    use HasFactory;
}
